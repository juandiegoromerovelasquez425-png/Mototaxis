const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
app.use(express.static(path.join(__dirname, "public")));

// La clave de Google Maps vive en el servidor (variable de entorno), no en el código.
app.get("/config.js", (req, res) => {
  res.type("js").send("window.MAPS_KEY=" + JSON.stringify(process.env.GOOGLE_MAPS_KEY || "") + ";");
});

// Acceso privado: solo entra quien tenga un código.
// DRIVER_CODE = tu código de mototaxista. CLIENT_CODES = códigos de tus clientes, separados por coma.
const DRIVER_CODE = process.env.DRIVER_CODE || "";
const CLIENT_CODES = (process.env.CLIENT_CODES || "").split(",").map((c) => c.trim()).filter(Boolean);
if (!DRIVER_CODE || !CLIENT_CODES.length) {
  console.error("Falta DRIVER_CODE o CLIENT_CODES. Ejemplo: DRIVER_CODE=moto123 CLIENT_CODES=juan,maria npm start");
  process.exit(1);
}

const wss = new WebSocketServer({ server });
const rides = new Map(); // id -> viaje
let counter = 0;

// Etapas: 1 buscando, 2 en camino, 3 llegó, 4 en viaje, 5 terminado
const send = (ws, o) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); };
const pub = (r) => ({ id: r.id, name: r.name, from: r.from, to: r.to, stage: r.stage,
  driver: r.driver, plate: r.plate, loc: r.loc });
const drivers = () => [...wss.clients].filter((c) => c.role === "driver" && c.online);
const pending = () => [...rides.values()].filter((r) => r.stage === 1).map(pub);

wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }

    if (m.type === "auth") {
      const code = String(m.code || "").trim();
      if (m.role === "driver" && code === DRIVER_CODE) ws.authRole = "driver";
      else if (m.role === "passenger" && CLIENT_CODES.includes(code)) { ws.authRole = "passenger"; ws.clientCode = code; }
      if (!ws.authRole) { send(ws, { type: "auth_fail" }); return ws.close(); }
      return send(ws, { type: "auth_ok", role: ws.authRole });
    }
    if (!ws.authRole) return; // sin código válido no se hace nada

    if (m.type === "driver_hello" && ws.authRole === "driver") {
      ws.role = "driver"; ws.name = String(m.name || "Mototaxista").slice(0, 40);
      ws.plate = String(m.plate || "").slice(0, 12); ws.online = true;
      send(ws, { type: "pending", rides: pending() });
    }

    if (m.type === "request" && ws.authRole === "passenger") {
      if (ws.rideId && rides.has(ws.rideId)) return; // un pedido a la vez
      const r = { id: ++counter, name: String(m.name || "Pasajero").slice(0, 40),
        from: m.from, to: m.to, stage: 1, pws: ws, dws: null, driver: null, plate: null, loc: null };
      ws.role = "passenger"; ws.rideId = r.id; rides.set(r.id, r);
      send(ws, { type: "ride", ride: pub(r) });
      drivers().forEach((d) => send(d, { type: "new", ride: pub(r) }));
    }

    if (m.type === "cancel") {
      const r = rides.get(ws.rideId); if (!r) return;
      closeRide(r, "cancelado");
    }

    if (m.type === "accept" && ws.role === "driver") {
      const r = rides.get(m.id);
      if (!r || r.stage !== 1) return send(ws, { type: "gone", id: m.id });
      r.stage = 2; r.dws = ws; r.driver = ws.name; r.plate = ws.plate; ws.rideId = r.id;
      send(r.pws, { type: "ride", ride: pub(r) });
      send(ws, { type: "ride", ride: pub(r) });
      drivers().forEach((d) => d !== ws && send(d, { type: "gone", id: r.id }));
    }

    if (m.type === "loc" && ws.role === "driver") {
      const r = rides.get(ws.rideId);
      if (r) { r.loc = { lat: m.lat, lng: m.lng }; send(r.pws, { type: "loc", loc: r.loc }); }
    }

    if (m.type === "advance" && ws.role === "driver") {
      const r = rides.get(ws.rideId); if (!r || r.dws !== ws) return;
      r.stage = Math.min(5, r.stage + 1);
      send(r.pws, { type: "ride", ride: pub(r) });
      send(ws, { type: "ride", ride: pub(r) });
      if (r.stage === 5) { rides.delete(r.id); ws.rideId = null; }
    }
  });

  ws.on("close", () => {
    if (ws.role === "passenger") { const r = rides.get(ws.rideId); if (r && r.stage < 4) closeRide(r, "cancelado"); }
    if (ws.role === "driver") {
      const r = rides.get(ws.rideId);
      if (r && r.stage < 5) { r.stage = 1; r.dws = null; r.driver = null; r.loc = null;
        send(r.pws, { type: "ride", ride: pub(r) });
        drivers().forEach((d) => send(d, { type: "new", ride: pub(r) })); }
    }
  });
});

function closeRide(r, why) {
  rides.delete(r.id);
  send(r.pws, { type: "closed", why });
  send(r.dws, { type: "closed", why });
  drivers().forEach((d) => send(d, { type: "gone", id: r.id }));
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log("Mototaxi Libre en http://localhost:" + PORT));
