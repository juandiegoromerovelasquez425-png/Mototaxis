# Mototaxi Libre (privado)

## Servidor
1. `npm install`
2. Define las variables y arranca:
   `GOOGLE_MAPS_KEY=tu_clave DRIVER_CODE=tu_codigo CLIENT_CODES=juan,maria,pedro npm start`
   - DRIVER_CODE: tu código de mototaxista.
   - CLIENT_CODES: un código por cliente. Para quitar a alguien, bórralo de la lista y reinicia.
3. Súbelo a Render/Railway/Fly.io (HTTPS obligatorio para el GPS).

## Android sin Android Studio (recomendado para empezar)
Abre la dirección del servidor en Chrome del celular > menú ⋮ > "Instalar app". Queda como app en la pantalla de inicio.

## APK real (opcional)
1. Pon tu dominio en `capacitor.config.json` (campo server.url).
2. `npm i @capacitor/core @capacitor/cli @capacitor/android`
3. `npx cap add android`
4. En `android/app/src/main/AndroidManifest.xml` agrega dentro de <manifest>:
   `<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>`
   `<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>`
5. `npx cap open android` y en Android Studio: Build > Build APK(s).
